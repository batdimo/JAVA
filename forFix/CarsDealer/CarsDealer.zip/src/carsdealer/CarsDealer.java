/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package carsdealer;


public class CarsDealer {
    private Vehichle vehicles[];
   int position=0;

    public CarsDealer() {
        vehicles = new Vehichle[10];
    }

    public Vehichle[] getVehicles() {
        return vehicles;
    }

    public void setVehicles(Vehichle[] vehicles) {
        this.vehicles = vehicles;
    }
  
    void add(Vehichle c) {vehicles [position++]=c;}
    
      
    void remove() {}
    void search() {}
    void print() {
        for (int i = 0; i < position; i++) {
            Vehichle vehichle = vehicles[i];
            System.out.println(vehichle);
        }
    }
}
