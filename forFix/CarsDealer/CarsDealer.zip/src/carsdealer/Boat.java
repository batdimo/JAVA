/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package carsdealer;

/**
 *
 * @author s504
 */
public class Boat extends Vehichle{
  double  widht;

    public Boat() {
    }

    public Boat(double widht ,String model, boolean hasWheels, double price) {
        super(model, hasWheels, price);
        this.widht=widht;
    }
}
